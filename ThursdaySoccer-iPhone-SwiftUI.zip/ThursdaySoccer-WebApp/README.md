# Thursday Soccer Web App

Works on:
- iPhone / iPad with Safari
- Android with Chrome
- Desktop browsers

Features:
- Add/remove player names
- $10 weekly fee by default
- Paid / unpaid tracking
- Weekly total collected and remaining
- Cash App and Venmo buttons
- Weekly history
- Saves data on the device using browser local storage
- Can be installed to the Home Screen as a PWA when hosted on HTTPS

Important:
This package must be uploaded to a web host (HTTPS) before other people can open it from their phones.
If each player opens the public link, they can use the page, but the current version stores data separately on each device.
For one shared live team list that everyone sees, a small cloud database/backend is needed.
